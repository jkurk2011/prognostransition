#### General Functions ####
# Author: Adam Armstrong
# Description: This file sources custom functions that have been written to simplify common tasks.

# This is a workaround that avoids a package installation issue
trace(utils:::unpackPkgZip, quote(Sys.sleep(2)), 
      at = which(grepl("Sys.sleep", body(utils:::unpackPkgZip), fixed = TRUE)))   

# Load Libraries
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/loadLibraries.R")
loadLibraries() # loads default libraries

#Asymetric Loss Function
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/asym_loss.R")


#Convert Census ID to S00XX id
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/censusid_convert.R")

# Case
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/case.R")

# Classificatio Metrics
source('C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/class_metrics.R')

# Copy To Clipboard
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/copyToClipboard.R")

# Connect to EDW
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/connectEDW.R")

# Connect to WERP
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/connectWERP.R")

#custom Logistic Function
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/custom_logistic_function.R")

#Curve Finder Function
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/curve_finder.R")

# CV.GLMNET Modelling Formula
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/cv.glmnet.formula.R")

# Double Squareroot Xform
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/dbl_sqrt_xform.R")

# Elas Loss
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/elas_loss.R")

# Execute SQL
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/executeSQL.R")

# Fit Metrics
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/fit_metrics.R")

# Fix Dates
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/fixDates.R")

# Get Formula
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/get_formula.R")

# Get Summary
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/getsummary.R")

# GLMNET Modelling Formula
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/glmnetFormula.R")

# Model Claims Saving
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/model_clms_save.R")

# Query EDW
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/queryEDW.R")

# Query WERP
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/queryWERP.R")

# Read SQL
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/readSQL.R")

# SAS Read
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/sas_read.R")

# SQL Write Table
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/sqlWriteTable.R")

# SQLite table
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/sqliteTable.R")



#### Plotting Functions ####

# Expand Colors
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/expand_colors.R")

# FIPS Choropleth
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/fips_choropleth.R")

# Humana Colors
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/getHumanaColors.R")

# Legend Title
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/legend_title.R")

# Theme - Jake Gaecke
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/theme_jg.R")

# Title with Subtitle
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/title_with_subtitle.R")

# Wordcloud Data
source("C:/Users/kurki/Desktop/Word Documents/DataScience/RProdCode/functions/wordcloud_data.R")
