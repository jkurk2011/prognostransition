
#create varied inflection point logistic curve

# Bound Multiplier: set to 1 when y must stay within bound,
# set <1 to let y go above upper bound,
# >1 for less than upper bound


#Slope Magnitude: Sets steepness of slope, sign(+/-) sensitive


#Inflection Parameter: 1.0 = Upper Bound/2, 
      # For Positive Slopes: <1 = steeper near Lower Bound, >1 = steeper near Upper Bound


# Lower Tail Adjuster: 
      #For Positive Slopes: Higher values = longer tail near Lower Bound, effect varies as inflection parameter changes

#Set Produce Plot to false for faster useage with grid search


# The function returns a function called specified Y which can be called from the output list
    #this function returns a specific y value based on the x value input to the function, 
      #the y is based on the defined logistic function 

require(ggplot2)
require(magrittr)
require(dplyr)

custom_logistic_fuction <- function(
                                    x = x_vals,
                                    upper_bound = 1,
                                    lower_bound = 0,
                                    start = 0,
                                    bound_multiplier = 1,
                                    slope_magnitude = 1,
                                    inflection_parameter = 1,
                                    lower_tail_adjuster = 1,
                                    produce_plot = FALSE
                                    ){
  
  
  

  #create y values
  y <- lower_bound + (
    (upper_bound - lower_bound) /
      
        (
          
          (
           bound_multiplier + 
           (
             lower_tail_adjuster *
           exp(-slope_magnitude*(x-start))
           )
           )
         
         **
           
           (1/inflection_parameter)
         )
  
  )
  
  
  
  #create useable function
  y_value_for_x <- function(input = specified_input){
    
    
    #create y values
    y_input <- lower_bound + (
      (upper_bound - lower_bound) /
        
        (
          
          (
            bound_multiplier + 
              (
                lower_tail_adjuster *
              exp(-slope_magnitude*(input-start))
              )
          )
          
          **
            
            (1/inflection_parameter)
        )
      
    )
    
    return(y_input)
    
  }
 
  
  
  
  if(produce_plot == TRUE){
   #create plot
  plot <- ggplot(data.frame(x = x, y = y), aes(x,y))+
            geom_point(alpha = .5)+
            geom_hline(yintercept = mean(y),
                      color = 'red', linetype = 'dashed')+
            theme_bw()+
            labs(caption = 'Red Dashed = Average Y')
  
  
  return_list <- list(data = data.frame(x = x, y = y),
                      specified_y = y_value_for_x,
                      plot = plot) 
  }else{
    return_list <- list(data = data.frame(x = x, y = y),
                        specified_y = y_value_for_x) 
  }
  
  
  return(return_list)
}


