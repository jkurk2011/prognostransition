require(tidyverse)
require(shiny)
require(magrittr)
require(latex2exp)


curve_finder <- function(data = seq(0, 1, .01), slope = 2, 
                           specific_x = .1, y_for_x = .5,
                           curve = 'Elasticity',
                           x_axis = 'X',
                           y_axis = 'Y',
                           type = 'decay'){
  
  
  if(type == 'decay'){
    #solve for z
    
    step_1 <- 1/(y_for_x)
    
    z <- log(step_1^(1/slope)-1)/log(specific_x)
    
    y <- 1/((1+data ** z)**slope)
    
    values <- y
    
    
    
    specific_y_for_x <- function(input){
      
      1/((1+input ** z)**slope)
      
    }
    
    
    #make plot
    plot <- ggplot(data.frame(x = data, y = values),
                   aes(x, y))+
      geom_line()+
      geom_point(aes(x = specific_x,
                     y = 1/((1+specific_x ** z)**slope),
                     color = 'Specified X'),
                 size =3)+
      theme_bw()+
      theme(legend.title = element_blank(), legend.position = 'bottom')+
      scale_y_continuous(breaks = seq(0,1, .1))+
      ggtitle(TeX(paste0('$', curve, ' = 1/(1 + x',
                         paste0('^{', round(z,5)), '})^{',
                         slope, '}$')))+
      xlab(x_axis)+
      ylab(y_axis)
    
    
    
    
    #shiny app
    
    
    
    ui <- fluidPage(
      
      sidebarPanel(width = 2,
                   numericInput('slope', 'Slope',
                                value = 2),
                   numericInput('specific_x', 'Specific X',
                                value = .1),
                   numericInput('y_for_x', 'Y Value for X',
                                value = .5),
                   textInput('curve', 'Curve Name',
                             'Elasticity'),
                   textInput('y_axis', 'Y Label',
                             'Y'),
                   textInput('x_axis', 'X Input',
                             'X'),
                   actionButton('execute', 'Run')),
      
      mainPanel(
        plotOutput('plot')
      )
      
    )
    
    server <- function(input, output, session) {
      
      z <- eventReactive(input$execute, {
        #solve for z
        
        step_1 <- 1/(input$y_for_x)
        
        z <- log(step_1^(1/input$slope)-1)/log(input$specific_x)
        z
        
        
        
      })
      
      values <- eventReactive(input$execute, {
        y <- 1/((1+seq(0,1,.01) ** z())**input$slope)
        
        values <- y
        values
      })
      
      
      plot_curve <- eventReactive(input$execute, {
        plot_curve <- ggplot(data.frame(x = seq(0,1,.01), y = values()),
                             aes(x, y))+
          geom_line()+
          geom_point(aes(x = input$specific_x,
                         y = 1/((1+input$specific_x ** z())**input$slope),
                         color = 'Specified X'),
                     size =3)+
          theme_bw()+
          theme(legend.title = element_blank(), legend.position = 'bottom')+
          scale_y_continuous(breaks = seq(0,1, .1))+
          ggtitle(TeX(paste0('$', input$curve, ' = 1/(1 + x',
                             paste0('^{', round(z(),5)), '})^{',
                             input$slope, '}$')))+
          xlab(input$x_axis)+
          ylab(input$y_axis)
        
        plot_curve
      })
      
      
      output$plot <- renderPlot({
        plot_curve()
      })
      
      
      
    }
    
    shiny_app <- shinyApp(ui, server)
    
    
    
    return(list(data = values, plot = plot, 
                y_for_x = specific_y_for_x,
                shiny_app = shiny_app))
    
    
  }else if(type == 'logistic'){
    
    
    
    
    #solve for z
    
    z <- ((specific_x/specific_x^2)/slope) * log(3)
    
    y <- (2/(1+exp(z*data * slope)))
    values <- y
    
    
    
    specific_y_for_x <- function(input){
      
      (2/(1+exp(z*input * slope)))
      
    }
    
    
    #make plot
    plot <- ggplot(data.frame(x = data, y = values),
                   aes(x, y))+
      geom_line()+
      geom_point(aes(x = specific_x,
                     y = (2/(1+exp(z*specific_x * slope))),
                     color = 'Specified X'),
                 size =3)+
      theme_bw()+
      theme(legend.title = element_blank(), legend.position = 'bottom')+
      scale_y_continuous(breaks = seq(0,2, .1))+
      ggtitle(TeX(paste0('$', curve, ' = 2/(1 + e^{',
                         paste0(round(z,5)), ' * x *',
                         slope, '}$')))+
      xlab(x_axis)+
      ylab(y_axis)
    
    
    
    
    #shiny app
    
    
    
    ui <- fluidPage(
      
      sidebarPanel(width = 2,
                   numericInput('slope', 'Slope',
                                value = 2),
                   numericInput('specific_x', 'Specific X',
                                value = .1),
                   numericInput('y_for_x', 'Y Value for X',
                                value = .5),
                   textInput('curve', 'Curve Name',
                             'Elasticity'),
                   textInput('y_axis', 'Y Label',
                             'Y'),
                   textInput('x_axis', 'X Input',
                             'X'),
                   actionButton('execute', 'Run')),
      
      mainPanel(
        plotOutput('plot')
      )
      
    )
    
    server <- function(input, output, session) {
      
      z <- eventReactive(input$execute, {
        #solve for z
        
        z <- ((input$specific_x/input$specific_x^2)/input$slope) * log(3)
        
       z
        
        
        
      })
      
      values <- eventReactive(input$execute, {
        
        
        y <- (2/(1+exp(z()*seq(-1,1,.01) * input$slope)))
        y
      })
      
      
      plot_curve <- eventReactive(input$execute, {
        plot_curve <- ggplot(data.frame(x = seq(-1,1,.01), y = values()),
                             aes(x, y))+
          geom_line()+
          geom_point(aes(x = input$specific_x,
                         y = (2/(1+exp(z()*input$specific_x * input$slope))),
                         color = 'Specified X'),
                     size =3)+
          theme_bw()+
          theme(legend.title = element_blank(), legend.position = 'bottom')+
          scale_y_continuous(breaks = seq(0,2, .1))+
          ggtitle(TeX(paste0('$', input$curve, ' = 2/(1 + e^{',
                             paste0(round(z(),5)), ' * x *',
                             input$slope, '}$')))+
          xlab(input$x_axis)+
          ylab(input$y_axis)
        
        plot_curve
      })
      
      
      output$plot <- renderPlot({
        plot_curve()
      })
      
      
      
    }
    
    shiny_app <- shinyApp(ui, server)
    
    
    
    return(list(data = values, plot = plot, 
                y_for_x = specific_y_for_x,
                shiny_app = shiny_app))
  }
  
}



