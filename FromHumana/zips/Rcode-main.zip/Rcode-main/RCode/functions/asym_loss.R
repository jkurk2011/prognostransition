require(tidyverse)
require(magrittr)


asym_loss <- function(data, pred, actual, weight, alpha, absolute = FALSE){
  
  resid <- data[, actual] - data[, pred]
  
  if(absolute == FALSE){
    weighted.mean(pull((resid ** 2) * ((sign(resid) + alpha) ** 2)),
                  pull(data[, weight]))
  }else{
    weighted.mean(pull(sqrt(resid ** 2) * ((sign(resid) + alpha) ** 2)),
                  pull(data[, weight]))
  }
  
  
}