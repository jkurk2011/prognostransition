#' Humana Colors
#'
#' Returns Humana colors in HEX values for use in plots. Use n to expand this color list with ligher and darker versions of each color.
#' @param n The number of colors to be output. If n is even, this function will output an additional color in order to include the original as the center color.
#' @keywords humana, colors, humcols, expand_colors
#' @export
#' @examples
#' getHumanaColors()
getHumanaColors <- function(n = 1){
  # returns a vector of Humana colors
  #             green,     plum,      grey,      dark green
  hum_cols <- c("#5C9A1B", "#AA005F", "#D5D5D5", "#1D5B2D") #humana colors
  hum_cols <- expand_colors(hum_cols, n)
  
  return(hum_cols)
}