###this function will convert a thirdpartyprocess censusID to the alphanumeric code that is used in census files
censusid_convert<-function(id=0){
a<-c(0,1,2,3,4,5,6,7,8,9,'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z')  
response<-c(a[floor(id/36^4)%%36+1],a[floor(id/36^3)%%36+1],a[floor(id/36^2)%%36+1],a[floor(id/36^1)%%36+1],a[floor(id/36^0)%%36+1])
return(response)
}

