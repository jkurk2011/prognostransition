#' Read Clipboard
#'
#' Reads data from the clipboard
#' @param
#' @keywords copy, data frame, import
#' @export
#' @examples
#' dat <- readClipboard()
readClipboard <- function(){
  # reads data from the clipboard
  return(read.delim("clipboard"))
}