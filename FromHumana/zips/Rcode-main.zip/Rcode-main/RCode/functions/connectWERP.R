#' Connect to WERP
#'
#' Estabilishes an ODBC connection to the WERP. If a user ID is not provided, the default account is used.
#' This function assumes you've set up an ODBC connection to WERP called WERP.
#' If not, set up in [Control Panel]>[Administrative Tools]>[Data Sources(ODBC)]>[User DSN]
#' @param userid String value holding the user ID.
#' @param password String value holding the password for the user ID specified.
#' @keywords sql, connect, edw, odbc
#' @export
#' @examples
#' connectEDW()
connectWERP <- function(userid, password, odbc='WERP') {
  # Close with disconnect(connection)
  library(RODBC) #database connections
  library(getPass) #get password functionality without RStudio dependency
  password <- invisible(getPass(msg = "Please enter password: ")) #request password at time of execution
  
  con_werp <- odbcConnect(odbc, uid=userid, pwd=password, believeNRows=FALSE, case="toupper")
  return(con_werp)
}