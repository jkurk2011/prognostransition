#' Query WERP
#'
#' Executes a SQL query on WERP and returns the result.
#' @param str_sql SQL code.
#' @param sqlFile Indicates that strSQL contains the exact location of a *.SQL file (instead of raw SQL code). Defaults to FALSE.
#' @param con_werp ODBC connection to WERP. Defaults to a new connections to WERP.
#' @keywords sql, werp, query, pull
#' @export
#' @examples
#' queryWERP('SELECT 1 FROM dual')
queryWERP <- function(str_sql, sqlFile = FALSE, con_werp=connectWERP()) {
  # Runs SQL query on WERP and returns result
  # If a connection is not provided, one will be established with the default account
  # str_sql = SQL code
  # sqlFile = indicates that strSQL contains exact location of .SQL file instead of raw SQL code
  
  executeSQL(str_sql, sqlFile, con = con_werp)
}