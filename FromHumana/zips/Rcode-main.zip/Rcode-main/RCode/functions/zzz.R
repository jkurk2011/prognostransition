.onLoad <- function(libname, pkgname){
  
  installed_packages <- as.data.frame(installed.packages()[,c(1,3:4)]) 
  package_list_for_install <- read.csv("R:/EmployerGroup/SharedCode/Prod/UtilityFunctions/package_list_for_install.csv", 
                                       header = TRUE)
  
  
  package_not_installed <- package_list_for_install$pkg_name[with(package_list_for_install, pkg_name %in% 
                                                                    installed_packages$Package) == 'FALSE']
  package_not_installed <- as.character(package_not_installed)
  
  print_str <- "Packages Loaded:"
  if(length(package_not_installed)>0){
    for(i in 1:length(package_not_installed)){
      #i<-5
      if(require(package_not_installed[i], character.only=TRUE)){
       
        print_str <- paste(print_str, paste("  ", package_not_installed[i]), sep = "\n")
      } else {
        install.packages(package_not_installed[i], dependencies = c("Depends", "Imports"))
        library(package_not_installed[i], character.only=TRUE)
        print_str <- paste(print_str, paste("Installed - ", package_not_installed[i]), sep = "\n")
      }
    }
  }
  # Print details of loading.
  
  for(i in 1:length(package_list_for_install$pkg_name)){
    #i<-5
      library(package_list_for_install$pkg_name[i], character.only=TRUE)
      print_str <- paste(print_str, paste("Loaded - ", package_list_for_install$pkg_name[i]), sep = "\n")
    
  }
  
  cat(print_str)
  
  version_history <- read.csv("R:/EmployerGroup/SharedCode/Prod/UtilityFunctions/version_tracker.csv",
                              header= TRUE)
  version_history_ordered <- version_history[order(version_history$DateReleased,decreasing = TRUE),]
  latest_version <- as.character(version_history_ordered[1,1])
  
  installed_version <- as.character(installed_packages$Version[installed_packages$Package == "UtilityFunctions"])
  installed_version <- paste0("UtilityFunctions_",installed_version)
    if(installed_version != latest_version){
      cat("A New version of UtilityFunctions is available for download!")
  }
}



