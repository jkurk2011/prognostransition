#' Provides case statement functionality inside of mutate function from dplyr.
#' @param x Column that has multiple values that you want to reassign to new values.
#' You must also provide current values = new values, delimited by commas. See example.
#' @keywords case, if
#' @export
#' @examples
#' mutate(dat,
#'        x = case(column,
#'                 "A" = 1,  #left side has values that column might take
#'                 "B" = 2)) #right side has the value you want to replace with
case <- function(x, ...){
  #Example:
  # mutate(x = case(column,
  #                  "A" = 1,  #left side has values that column might take
  #                  "B" = 2)) #right side has the value you want to replace with
  if(is.factor(x)){
    x <- as.character(x)
  }
  return(sapply(x, switch, ...))
}
